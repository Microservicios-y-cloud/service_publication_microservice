package co.edu.javeriana.msc.turismo.service_publication_microservice.dto;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record LocationResponse (
    String address,
    Double latitude,
    Double longitude,
    String country,
    String city,
    String municipality
){}
