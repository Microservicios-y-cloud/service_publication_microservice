package co.edu.javeriana.msc.turismo.service_publication_microservice.dto;

public record FoodTypeResponse (
    Long FoodTypeId,
    String name
) {
}
