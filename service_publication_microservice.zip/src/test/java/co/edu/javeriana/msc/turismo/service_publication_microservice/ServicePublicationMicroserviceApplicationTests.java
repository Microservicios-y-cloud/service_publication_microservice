package co.edu.javeriana.msc.turismo.service_publication_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicePublicationMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
